import React from 'react';
import Contactus from './components/Container';


const ContactUsIndex = ({dataRes}) => {

  return (
    <Contactus dataRes={dataRes}/>
  );
};

export default ContactUsIndex;

