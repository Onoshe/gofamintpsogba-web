

function getPhotosGalArr(){
    const photosGalArr = [
            
    ];
    return photosGalArr
}


export { getPhotosGalArr};