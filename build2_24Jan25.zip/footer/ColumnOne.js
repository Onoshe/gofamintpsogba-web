'use client'
import React from 'react'



const ColumnOne = () => {
  return (
    <div className='p-5 md:p-10'>
      <h1 className='font-archivo text-xl sm:text-4xl pb-5 bold md:text-left'>About </h1>
      <h1 className='text-sm sm:text-xl md:text-left text-[#fad20a] pb-5'>
        GOFAMINT PACESETTERS OGBA
      </h1>
      <h1 className='text-sm sm:text-base md:text-justify text-[silver]'>
        {text1}
      </h1>
    </div>
  )


}

export default ColumnOne





const text1 = "The Gospel Faith Mission International (GOFAMINT) Pacesetters Assembly, Ogba, is the District Headquaters Church of Ogba District. GOFAMINT is the the Church with the Word for the World, founded on the Solid Rock by God, through a small group of committed men and women led by the late Pastor (Dr) R. A. George at Iwaya, Yaba Lagos, has transformed into a divine legacy that has today assumed a global dimension.";