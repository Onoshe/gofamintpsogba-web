<?php    
        // List of allowed origins
        $allowed_origins = [
            'http://localhost:3000',
            'http://example.com',
            'http://another-example.com'
        ];
        // Get the origin of the request
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        // Check if the origin is in the allowed list
        if (in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: $origin");
        }
        // Set additional headers
        header("Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");

        // Read the JSON data from the POST request
        $reqMethod = $_SERVER['REQUEST_METHOD'];
        $postData = file_get_contents('php://input');
        $decodedData = json_decode($postData, true);

        // Handle preflight requests
        if ($reqMethod == 'OPTIONS') {
            http_response_code(204);
            exit();
        }
        
          
        //echo json_encode(['ok' => false, 'error' =>   $postData ]);
        //return;  

        require_once 'headers/getRequestBodyBase.php'; //$act, $domain
        require_once 'configs/DotEnvLoader.php';
        require_once 'configs/checkAuthorization.php';
        require_once 'configs/connectToDb.php';
        require_once 'tables/coaStructure.php';
        require_once 'tables/chartOfAccount.php';
        require_once 'tables/products.php';
        require_once 'tables/personalAccountCustomers.php';
        require_once 'tables/personalAccountVendors.php';
        require_once 'tables/users_account.php';
        require_once 'tables/activityLog.php';
        require_once 'tables/transactions.php';
        require_once 'tables/settings.php';
        require_once 'utils/createTables.php';
        require_once 'utils/deleteTables.php';
        require_once 'utils/insertTableDatas.php';
        require_once 'utils/activateOrDeactivateClient.php';
        
            
        use DevCoder\DotEnv;
        // Load environment variables
        (new DotEnv(__DIR__ . '/.env'))->load();
        checkAuthorization(getenv('TOKEN'));

        require_once 'tables/_indexTables.php'; // $tableNames, $createQueries, $insertQueries, $newClientTables
        
        
        /*$tableNames = [
            "COASTRUCTURE" => $domain."_coastructure",
            "CHARTOFACCOUNT" => $domain."_chartofaccount",
            "PRODUCTS" => $domain."_products",
            "CUSTOMERS" => $domain."_customers",
            "VENDORS" => $domain."_vendors",
            "TRANSACTIONS" => $domain."_transactions",
            "TRANSACTIONSDETAILS" => $domain."_transactionsdetails",
            "USERSACCOUNT" => $domain."_usersaccount",
            "ACTIVITYLOG" => $domain."_activitylog",
        ];
        $tableRefs = [
            "CHARTOFACCOUNT" => $domain."_coastructure",
            "TRANSACTIONSDETAILS" => $domain."_transactions",
            "ACTIVITYLOG" => $domain."_usersaccount",
        ];
        $createQueries =[
            "COASTRUCTURE" => createCoaStructure($tableNames['COASTRUCTURE']),
            "CHARTOFACCOUNT" => createChartOfAccount($tableNames['CHARTOFACCOUNT'], $tableRefs['CHARTOFACCOUNT']),
            "PRODUCTS" => createProducts($tableNames['PRODUCTS']),
            "CUSTOMERS" => createCustomers($tableNames['CUSTOMERS']),
            "VENDORS" => createVendors($tableNames['VENDORS']),
            "TRANSACTIONS" => createTransactions($tableNames['TRANSACTIONS']),
            "TRANSACTIONSDETAILS" => createTransactionDetails($tableNames['TRANSACTIONSDETAILS'], $tableRefs['TRANSACTIONSDETAILS']),
            "ACTIVITYLOG" => createActivityLog($tableNames['ACTIVITYLOG'], $tableRefs['ACTIVITYLOG']),
            "USERSACCOUNT" => createUsersAccount($tableNames['USERSACCOUNT'])
        ];
        $insertQueries =[
            "COASTRUCTURE"  => insertDataCoaStructure($tableNames['COASTRUCTURE']),
            "CHARTOFACCOUNT" => insertDataToChartOfAccount($tableNames['CHARTOFACCOUNT']),
            "PRODUCTS" => insertDataToProducts($tableNames['PRODUCTS']),
            "CUSTOMERS" => insertDataToVendors($tableNames['CUSTOMERS']),
            "VENDORS" => insertDataToCustomers($tableNames['VENDORS'])
        ];*/

        
        if($act === "CREATE"){
             require_once 'headers/getRequestBodyForCID.php';   //extract $tables
             createTablesInDb($tables, $tableNames, $conn, $createQueries);
        }else if($act === "INSERT"){
            require_once 'headers/getRequestBodyForCID.php';
            insertDataToDbTable($tables, $tableNames, $conn, $insertQueries);
        }else if($act === "DROP"){
            require_once 'headers/getRequestBodyForCID.php';
            deleteTablesFromDatabase($tables, $tableNames, $conn);
        }else if($act === "ACTIVATE"){
            require_once 'headers/getRequestBodyForAD.php';
            activateOrDeactivateClient($act, $clientId, $conn);
        }else if($act === "DEACTIVATE"){
            require_once 'headers/getRequestBodyForAD.php';
            activateOrDeactivateClient($act, $clientId, $conn);
        }else if($act === "REMOVE"){
            require_once 'headers/getRequestBodyForAD.php';
            activateOrDeactivateClient($act, $clientId, $conn);
        }else if($act === "CREATECLIENT"){
            require_once 'headers/getRequestBodyForAD.php';
            //activateOrDeactivateClient($act, $clientId, $conn);
        }else if($act === "DROPCLIENT"){
            require_once 'headers/getRequestBodyForAD.php';
            //activateOrDeactivateClient($act, $clientId, $conn);
        }else{
            echo json_encode(['ok' => false, 'msg' => "Unrecognised action"]);
        }
        
        $conn->close();