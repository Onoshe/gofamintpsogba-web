<?php

function getLocalDbConfigs(){
    $servername = "localhost";
    $hostname = "root";
    $password = "";
    $dbname = "developer";

    // Create connection
    $conn = new mysqli($servername, $hostname, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }else{
        return $conn;
    }
  
  }

  
//Connect the right database
$conn =  getLocalDbConfigs();