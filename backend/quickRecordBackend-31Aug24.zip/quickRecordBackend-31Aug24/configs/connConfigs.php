
<?php

 function connectToCSdb() {
     $servername = "gofamintpsogba.org";  
    $username = "gofamint_developer";
    $password = "jfP{D-T2*e@H";
    $dbname = "gofamint_churchSiteDatabase";
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    
    return $conn; 
 }
 
 function connectToCXdb() {
     $servername = "localhost";  
    $username = "gofamint_developer";
    $password = "jfP{D-T2*e@H";
    $dbname = "gofamint_countiXpressDB";
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    
    return $conn; 
 }
 
 function connectToFFdb() {
     $servername = "localhost";  
    $username = "gofamint_developer";
    $password = "jfP{D-T2*e@H";
    $dbname = "gofamint_filmflick";
    
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    
    // Check connection
    if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
    }
    
    return $conn; 
 }
 
 
 
?>


<?php
