<?php

 /*_________________________________________________
    route: https://phpserver.gofamintpsogba.org/patch
    postData example: 
        {  
            "db":"ff",
            "tableName":"EMPLOYEES",
             "patchQuery": "UPDATE EMPLOYEES SET lastname ='Benedict', age = '29', description='Hello Benedict' WHERE id = 2"
          }
         
  ____________________________________________________________*/
 
 require 'configs/connConfigs.php';

    if($_SERVER['REQUEST_METHOD'] === 'PATCH') {
        
        // Read the JSON data from the POST request
        $postData = file_get_contents('php://input');
        $decodedData = json_decode($postData, true);
        
        // Check if decoding was successful
        if(isset($decodedData['tableName']) && isset($decodedData['patchQuery']) && isset($decodedData['db'])){
            // Extract values from decoded data
            $db = $decodedData['db'];
            $tableName = $decodedData['tableName'];
            $patchQuery = $decodedData['patchQuery'];
            
            //Connect the right database
            $conn;
            if($db === "cs"){
                $conn = connectToCSdb();
            }else if($db === "cx"){
                 $conn = connectToCXdb();
            }else if($db === "ff"){
                 $conn = connectToFFdb();
            }else{
              echo json_encode(['ok' => false, 'error' => 'Unrecognised database']);
              return;  
            }
        
            $data = updateDb($conn, $tableName, $patchQuery);
           echo $data;
        } else {
            echo json_encode([ "ok" => false, "message" => "Invalid or missing parameter."]);
        }
    }
 
 
function updateDb($conn, $tableName, $patchQuery) {

    // Prepare and execute the query
    $stmt = $conn->prepare($patchQuery);

    if (!$stmt) {
        // Handle query preparation error
       return json_encode(['ok' => false, 'error' => "Error preparing query"]);
    }

    // Execute the query
    $stmt->execute();

    // Check if the update was successful
    if ($stmt->affected_rows > 0) {
        
        // Retrieve the updated table
        $updatedTable = $conn->query("SELECT * FROM $tableName") ->fetch_all(MYSQLI_ASSOC);
            
        $stmt->close();
        return json_encode(['ok' => true, 'message' => "Data update successful", 'newTable' => $updatedTable]);
    } else {
        $stmt->close();
       return json_encode(['ok' => false, 'message' => "No row was updated"]);
    }
}


?>