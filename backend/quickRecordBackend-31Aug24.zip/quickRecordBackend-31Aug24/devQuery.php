<?php
         header("Access-Control-Allow-Origin: *");
         header("Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS");
         header("Access-Control-Allow-Headers: Content-Type, Authorization");                   

        // List of allowed origins
        $allowed_origins = [
            'http://localhost:3000',
            'http://example.com',
            'http://another-example.com'
        ];
        // Get the origin of the request
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        // Check if the origin is in the allowed list
        if (in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: $origin");
        }
        // Set additional headers
        header("Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS");
        header("Access-Control-Allow-Headers: Content-Type, Authorization");

        // Handle preflight requests
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            http_response_code(204);
            exit();
        }

        require_once 'configs/DotEnvLoader.php';
        require_once 'configs/localConnect.php';

        
        $conn = getLocalDbConfigs();

        $url = $_SERVER['REQUEST_URI']; // get the URL
        $method = $_SERVER['REQUEST_METHOD']; // get the request method
        $postData = file_get_contents('php://input');
        $decodedData = json_decode($postData, true);

    if ($method === 'POST') {
        //$sql = $_POST['query'];
        $sql = $decodedData['query'];

        // Prepare and bind
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(array('error' => "Error: " . $conn->error));
            exit;
        }

        // Execute the query
        if ($stmt->execute()) {
            $result = $stmt->get_result();
            if ($result) {
                $data = array();
                while ($row = $result->fetch_assoc()) {
                    $data[] = $row;
                }
                echo json_encode($data);
            } else {
                echo json_encode(array('success' => "Query executed successfully"));
            }
        } else {
            echo json_encode(array('error' => "Error: " . $stmt->error));
        }

        $stmt->close();
    } else {
        echo json_encode(array('error' => "Invalid request method", 'ok'=> false));
    }

    $conn->close();
