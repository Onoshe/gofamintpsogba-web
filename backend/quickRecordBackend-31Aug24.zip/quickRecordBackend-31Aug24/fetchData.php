<?php

function fetchData($conn, $table, $returnType) {
    
    if($table === "KOSOFECOOP_ALL"){
            $sql1 = "SELECT * FROM KOSOFECOOP_COA";
            $sql2 = "SELECT * FROM KOSOFECOOP_TRANSACTIONS";
            $sql3 = "SELECT * FROM KOSOFECOOP_VENDORS";
            $sql4 = "SELECT * FROM KOSOFECOOP_CUSTOMERS";
            $sql5 = "SELECT * FROM KOSOFECOOP_ACTIVITIES";
            
            $resultTrans = $conn->query($sql2);
            $resultVendors = $conn->query($sql3);
            $resultCustomers = $conn->query($sql4);
            $resultActivities = $conn->query($sql5);
            $resultCOA = $conn->query($sql1);
    
    
         if ($resultCOA) {
           if ($resultCOA->num_rows > 0) {
            
            $coa = $resultCOA->fetch_all(MYSQLI_ASSOC);
            $trans = $resultTrans->fetch_all(MYSQLI_ASSOC);
            $vendors = $resultVendors->fetch_all(MYSQLI_ASSOC);
            $customers = $resultCustomers->fetch_all(MYSQLI_ASSOC);
            $activities = $resultActivities->fetch_all(MYSQLI_ASSOC);
            return json_encode(['ok' => true, 'coa' => $coa, 'transactions' => $trans, 'vendors' => $vendors, 'customers' => $customers, 'activities' => $activities, ]);
            }
         }
    }else {
            
        
                $sql = "SELECT * FROM $table";
               
                $result = $conn->query($sql);
                 $data = $result->fetch_all(MYSQLI_ASSOC);
                 
                return json_encode(['ok' => true, 'coa' => $data]);
                
                if ($result) {
                    if ($result->num_rows > 0) {
                        $data = $result->fetch_all(MYSQLI_ASSOC);
                        
                        return isset($returnType)? json_encode($data) : json_encode(['ok' => true, 'coa' => $data]);
                    } else {
                       return json_encode(['ok' => false, 'msg' => 'Error in fetching message' ]);
                    }
                } else {
                    return json_encode(['ok' => false, 'msg' => 'Error in fetching message' ]);
                }
        
    }
    
}
?>