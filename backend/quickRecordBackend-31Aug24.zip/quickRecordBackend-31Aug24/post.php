<?php



    if($_SERVER['REQUEST_METHOD'] === 'POST') {
        
        // Read the JSON data from the POST request
        $postData = file_get_contents('php://input');
        $decodedData = json_decode($postData, true);
        
        // Check if decoding was successful
        if(isset($decodedData['tableName']) && isset($decodedData['insertQuery']) && isset($decodedData['rows']) && isset($decodedData['db'])){
            // Extract values from decoded data
            $db = $decodedData['db'];
            $tableName = $decodedData['tableName'];
            $insertQuery = $decodedData['insertQuery'];
            $rows = $decodedData['rows'];
            
            //Connect the right database
            $conn;
            if($db === "cs"){
                $conn = connectToCSdb();
            }else if($db === "cx"){
                 $conn = connectToCXdb();
            }else if($db === "ff"){
                 $conn = connectToFFdb();
            }else{
              echo json_encode(['ok' => false, 'error' => 'Unrecognised database']);
              return;  
            }
        
            $data = postDataToTheDb($conn, $decodedData, $tableName, $insertQuery, $rows);
           echo $data;
        } else {
            echo json_encode([ "ok" => false, "message" => "Invalid or missing parameter."]);
        }
    }
 
function postDataToTheDb($conn, $decodedData, $tableName, $insertQuery, $rows){

    // If deletePrevTable is true, delete all data from the table
    $deletePrevTable = isset($decodedData['deletePrevTable']) ? $decodedData['deletePrevTable'] : false;
    if ($deletePrevTable) {
        $deleteQuery = "DELETE FROM $tableName";
        $deleteStmt = $conn->prepare($deleteQuery);
            
        // Check for query preparation error
        if (!$deleteStmt) {
            return json_encode(['ok' => false, 'message' => "Error preparing delete query: " . $conn->error]);
        }

        // Execute the delete query
        $deleteResult = $deleteStmt->execute();

        // Check for execution error
        if ($deleteResult === false) {
            return json_encode(['ok' => false, 'message' => "Error executing delete query: " . $deleteStmt->error]);
        }

        // Reset the auto-increment key
        $resetAutoIncrementQuery = "ALTER TABLE $tableName AUTO_INCREMENT = 1";
        $conn->query($resetAutoIncrementQuery);
    
        $deleteStmt->close();
    }


    $valueStrings = [];
    foreach($rows as $row){
        $valueStrings[] = "(" . implode(", ", array_map(function($rows) {
            return "'" . $rows . "'";
        }, $row)) . ")";
    }
    $sql = $insertQuery . " " . implode(", ", $valueStrings);
    
    // Execute the SQL query
    if ($conn->query($sql) === TRUE) {
        
        //fetch the new table and return
         $sqlFetch = "SELECT * FROM $tableName";
        $result = $conn->query($sqlFetch);
        $data = $result->fetch_all(MYSQLI_ASSOC);
    
        return json_encode(['ok' => true, 'message' => 'Data inserted successfully', 'newTable' => $data]);
    } else {
        return json_encode(['ok' => false, 'message' => "Error preparing insert query: " . $conn->error]);
    }
    
    $stmt->close();
}

        
?>