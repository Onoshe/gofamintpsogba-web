<?php
  header("Access-Control-Allow-Origin: *");
  header("Access-Control-Allow-Methods: GET, POST, PATCH, OPTIONS");
  header("Access-Control-Allow-Headers: Content-Type, Authorization");
  
    //require 'configs/connConfigs.php';
    require_once 'configs/connConfigs.php';
    require_once 'configs/localConnect.php';
    
    $conn = getLocalDbConfigs();
    
    
    $sql = "SELECT * FROM practice_db";
    
    $result = $conn->query($sql);
    $data = $result->fetch_all(MYSQLI_ASSOC);
    
    if(isset($data)){
      echo(json_encode(['ok' => true, 'data' => $data]));   
    }else{
        echo(json_encode(['ok' => false, 'msg' => "Failed to fetch data"]));
    } 
     

    $conn->close();
