<?php

function subscriptions (){

    return "CREATE TABLE IF NOT EXISTS subscriptions (
            id INT(11) NOT NULL AUTO_INCREMENT,
            companyId VARCHAR(255),
            companyDomain VARCHAR(255),
            subscriptionDate	VARCHAR(255),
            subscriptionAmount	VARCHAR(255),
            subscriptionType	VARCHAR(255),
            description	      VARCHAR(800),
            deleted INT(1) NOT NULL DEFAULT 0,
            receivingBank	VARCHAR(255),
            inactive INT(1) NOT NULL DEFAULT 0 COMMENT '1 is activation',
            updatedAt VARCHAR(255),
            createdAt VARCHAR(255),
            PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
};

//VARCHAR(255) COMMENT 'This can be Payment, Receipt, Journal, etc',
//FOREIGN KEY (companyId) REFERENCES _clients (id) ON DELETE CASCADE ON UPDATE CASCADE,
//FOREIGN KEY (companyDomain) REFERENCES _clients (companyDomain) ON DELETE CASCADE ON UPDATE CASCADE
/*
INSERT INTO `subscriptions`(`companyId`, `companyDomain`, `subscriptionDate`, `subscriptionAmount`, `subscriptionType`, `description`, `receivingBank`) VALUES ('DEMO', 'DEMO', '2023-02-28', '100000','Premium', 'First subscription', 'GTbank')
INSERT INTO `subscriptions`(`companyId`, `companyDomain`, `subscriptionDate`, `subscriptionAmount`, `subscriptionType`, `description`, `receivingBank`) VALUES ('DEMO', 'DEMO', '2024-03-01', '100000','Premium', 'Second subscription', 'Zenith');
*/