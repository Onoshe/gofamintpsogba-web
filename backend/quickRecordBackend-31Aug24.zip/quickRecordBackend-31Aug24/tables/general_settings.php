<?php

function settings ($tableName){

    return "CREATE TABLE IF NOT EXISTS _settings (
            id INT(11) NOT NULL AUTO_INCREMENT,
            name	VARCHAR(255),
            description	VARCHAR(255),
            column1	VARCHAR(255),
            column2	VARCHAR(255),
            column3	VARCHAR(255),
            column4	VARCHAR(255),
            column5	VARCHAR(255),
            column6	VARCHAR(255),
            column7	VARCHAR(255),
            column8	VARCHAR(255),
            column9	VARCHAR(255),
            column10	VARCHAR(255),
            longText TEXT,
            longText2 TEXT,
            updatedAt VARCHAR(255),
            createdAt VARCHAR(255),
            inactive INT(1) NOT NULL DEFAULT 0 COMMENT '1 is activation',
            deleted INT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
};

function settingsClient ($tableName){

    return "CREATE TABLE IF NOT EXISTS _settings_clients (
            id INT(11) NOT NULL AUTO_INCREMENT COMMENT 'Being Company unique Id or identifyer',
            companyName VARCHAR(512),
            companyDomain VARCHAR(512) UNIQUE NOT NULL COMMENT 'Of type profitableway in profitableway_customers & profitableway@fred.ola and must be in lowercase',
            address	VARCHAR(255),
            email	VARCHAR(255),
            contactPersonName	VARCHAR(255),
            contactPersonPhoneNo	VARCHAR(255),
            businessType VARCHAR(255),
            packagePlan	VARCHAR(255),
            registeredDate	VARCHAR(255),
            subscriptionExpirationDate	VARCHAR(255),
            inactive ENUM('1', '0') NOT NULL DEFAULT '0' COMMENT 'Company only accessable if active',
            updatedAt VARCHAR(255),
            createdAt VARCHAR(255),
            PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;";
};