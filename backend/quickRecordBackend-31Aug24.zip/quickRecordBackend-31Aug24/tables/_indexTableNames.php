<?php
    
    $tableNames = [
        //"COASTRUCTURE" => $domain."_coastructure",
        "CHARTOFACCOUNT" => $domain."_chartofaccount",
        "PRODUCTS" => $domain."_products",
        "CUSTOMERS" => $domain."_customers",
        "VENDORS" => $domain."_vendors",
        "TRANSACTIONS" => $domain."_transactions",
        "TRANSACTIONSDETAILS" => $domain."_transactionsdetails",
        "USERSACCOUNT" => $domain."_usersaccount",
        "ACTIVITYLOG" => $domain."_activitylog",
    ];


    function getTableName($domain){
        //$tableNames = $tableNames;
        //return $tableNames;
    }